![panel](panel.png)


for a short demonstration, move "example/examples.ipynb" out 2 levels and run

more info coming soon...
