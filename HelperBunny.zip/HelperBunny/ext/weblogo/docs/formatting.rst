===============
Logo Formatting
===============

.. contents:: :local:
.. currentmodule:: weblogo


.. automodule:: weblogo.logo_formatter
	:members:
